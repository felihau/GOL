public class Dimension {

    private int breite = 30;
    private int height = 30;

    Zelle[][] zellen = new Zelle[breite][height];
    
    Dimension() {
        for (int i = 0; i < breite; i++) {
            for(int j = 0; j < height; j++) {
               zellen[i][j] = new Zelle();
            }
        }
    }
    
    
    
    
    public int getBreite() {
        return breite;
    }

    public void setBreite(int breite) {
        this.breite = breite;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }


    

}
