public class Controller {
    void neuerZyklus(){

    }
}
