import javax.swing.*;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import java.awt.*;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {


    public static void main(String[] args) {
        Dimension spielFeld = new Dimension();
         JButton[][] buttons=new JButton[spielFeld.getBreite()][spielFeld.getHeight()];

        //BasicOptionPaneUI.ButtonActionListener bt = new
        JFrame window = new JFrame("Hello world");
        window.setSize(800,800);
        window.setVisible(true);

        window.setLayout(new GridLayout(spielFeld.getBreite(), spielFeld.getHeight()));
        for (int i=0; i < spielFeld.getBreite(); i++) {
            for (int j = 0; j < spielFeld.getHeight(); j++){
                buttons[i][j] = new JButton();
                window.add(buttons[i][j]);
            }
           //buttons[i].addActionListener(bt);
        }


    }
}