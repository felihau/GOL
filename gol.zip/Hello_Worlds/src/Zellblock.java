public class Zellblock {
    Zelle zelleN;
    Zelle zelleNW;
    Zelle zelleNE;
    Zelle zelleE;
    Zelle zelleSE;
    Zelle zelleS;
    Zelle zelleSW;
    Zelle zelleW;
    Zelle zelleMain;

    public Zelle getZelleN() {
        return zelleN;
    }

    public void setZelleN(Zelle zelleN) {
        this.zelleN = zelleN;
    }

    public Zelle getZelleNW() {
        return zelleNW;
    }

    public void setZelleNW(Zelle zelleNW) {
        this.zelleNW = zelleNW;
    }

    public Zelle getZelleNE() {
        return zelleNE;
    }

    public void setZelleNE(Zelle zelleNE) {
        this.zelleNE = zelleNE;
    }

    public Zelle getZelleE() {
        return zelleE;
    }

    public void setZelleE(Zelle zelleE) {
        this.zelleE = zelleE;
    }

    public Zelle getZelleSE() {
        return zelleSE;
    }

    public void setZelleSE(Zelle zelleSE) {
        this.zelleSE = zelleSE;
    }

    public Zelle getZelleS() {
        return zelleS;
    }

    public void setZelleS(Zelle zelleS) {
        this.zelleS = zelleS;
    }

    public Zelle getZelleSW() {
        return zelleSW;
    }

    public void setZelleSW(Zelle zelleSW) {
        this.zelleSW = zelleSW;
    }

    public Zelle getZelleW() {
        return zelleW;
    }

    public void setZelleW(Zelle zelleW) {
        this.zelleW = zelleW;
    }

    public Zelle getZelleMain() {
        return zelleMain;
    }

    public void setZelleMain(Zelle zelleMain) {
        this.zelleMain = zelleMain;
    }
}
