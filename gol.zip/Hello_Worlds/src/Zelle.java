public class Zelle {
    boolean zelleZustand;

    void toggle(){
        zelleZustand = !zelleZustand;
    }
}
