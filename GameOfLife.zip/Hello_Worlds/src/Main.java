import javax.swing.*;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import java.awt.*;
import java.awt.color.ColorSpace;
import java.awt.event.*;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {


    public static void main(String[] args) {
        Dimension spielFeld = new Dimension();


        JFrame window = new JFrame("Hello world");
        window.setSize(800, 800);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        window.setVisible(true);
        Controller controller = new Controller();
        window.setLayout(new GridLayout(spielFeld.getBreite(), spielFeld.getHeight()));
        controller.initView(window);


        KeyListener keyclick = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_SPACE) {
                    controller.zug();
                    window.repaint();
                }
                if (key == KeyEvent.VK_LEFT)
                    controller.randomInit();
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        };


window.addKeyListener(keyclick);



    }
}