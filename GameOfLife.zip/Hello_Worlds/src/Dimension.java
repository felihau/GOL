import javax.swing.*;

public class Dimension {

    private int breite = 120;
    private int height = 120;

    Zelle[][] zellen = new Zelle[breite][height];
    
    Dimension() {
        for (int i = 0; i < breite; i++) {
            for(int j = 0; j < height; j++) {
               zellen[i][j] = new Zelle(new JButton());
                zellen[i][j].setztZustandNaechsteRunde(((int) (Math.random() * 10d) > 4) ? true : false);
            }
        }
    }
    
    
    
    
    public int getBreite() {
        return breite;
    }

    public void setBreite(int breite) {
        this.breite = breite;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }


    

}
