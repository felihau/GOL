import javax.swing.*;
import java.awt.*;

public class Zelle {


    public boolean isZustandJetzt() {
        return zustandJetzt;
    }

    public boolean isZustandNaechsteRunde() {
        return zustandNaechsteRunde;
    }

    private boolean zustandJetzt;
    private boolean zustandNaechsteRunde;

    private final JButton view;

    public Zelle(JButton view) {
        this.view = view;
    }

    public JButton getView() {
        return view;
    }

    public void setzeNaechsteRundeInJetzt() {
        zustandJetzt = zustandNaechsteRunde;

    }

    public void setztZustandNaechsteRunde(boolean zustand) {
        this.zustandNaechsteRunde = zustand;
    }
}
