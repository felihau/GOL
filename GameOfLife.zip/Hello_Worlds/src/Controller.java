import javax.swing.*;
import java.awt.*;

public class Controller {
    private Dimension spielFeld = new Dimension();

    boolean Zustandsspeicher[][] = new boolean[spielFeld.getBreite()][spielFeld.getHeight()];


    void initView(JFrame frame) {
        for (int i = 0; i < spielFeld.getBreite(); i++) {
            for (int j = 0; j < spielFeld.getHeight(); j++) {
                frame.add(spielFeld.zellen[i][j].getView());
                //buttons[i][j].addActionListener(bt);
            }
            //buttons[i].addActionListener(bt);
        }
    }

    /**
     * naechster schritt
     */

    void berechneSpielfeld() {

        for (int i = 0; i < spielFeld.getBreite(); i++) {
            for (int j = 0; j < spielFeld.getHeight(); j++) {
                spielFeld.zellen[i][j].setzeNaechsteRundeInJetzt();
                spielFeld.zellen[i][j].getView().setBackground(spielFeld.zellen[i][j].isZustandJetzt() ? Color.BLACK : Color.WHITE);
                //Zustandsspeicher[i][j] = spielFeld.zellen[i][j].isZustandJetzt();
            }
        }
    }

    void nächsterzug() {
        for (int i = 0; i < spielFeld.getHeight(); i++) {
            for (int j = 0; j < spielFeld.getBreite(); j++) {
                Zelle zelle = spielFeld.zellen[i][j];
                int lebendeNachbarn = zaehleLebendeNachbarn(i, j);
                if (zelle.isZustandJetzt()) {
                    if (lebendeNachbarn < 2 || lebendeNachbarn > 3) {
                        zelle.setztZustandNaechsteRunde(false);
                    }
                } else {
                    if (lebendeNachbarn == 3) {
                        zelle.setztZustandNaechsteRunde(true);
                    }
                }
            }
        }

        for (int x = 0; x < spielFeld.getBreite(); x++) {
            for (int y = 0; y < spielFeld.getHeight(); y++) {


            }
        }
    }
    void randomInit() {
               var breite= spielFeld.getBreite();
               var height=spielFeld.getHeight();
               var zellen=spielFeld.zellen;
        for (int i = 0; i < breite; i++) {
        for(int j = 0; j < height; j++) {
            zellen[i][j].setztZustandNaechsteRunde(((int) (Math.random() * 10d) > 4) ? true : false);
        }
    }
}
    int zaehleLebendeNachbarn(int x, int y) {
        int lebendeNachbarn = 0;
        for (int k = -1; k <= 1; k++) {
            for (int l = -1; l <= 1; l++) {
                if (k == 0 && l == 0) {
                    // Ignoriere die aktuelle Zelle
                    continue;
                }
                int nachbarX = x + k;
                int nachbarY = y + l;
                if (nachbarX >= 0 && nachbarX < spielFeld.getBreite() && nachbarY >= 0 && nachbarY < spielFeld.getHeight()
                        && spielFeld.zellen[nachbarX][nachbarY].isZustandJetzt()) {
                    lebendeNachbarn++;
                }
            }
        }
        return lebendeNachbarn;
    }

              void zug() {
        berechneSpielfeld();
        nächsterzug();
    }
}
