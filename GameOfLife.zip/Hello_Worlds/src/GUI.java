import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class GUI {

    private JFrame window;
    private Controller controller;

    public GUI() {
        Dimension spielFeld = new Dimension();
        window = new JFrame("Hello world");
        window.setSize(800, 800);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        controller = new Controller();
        window.setLayout(new GridLayout(spielFeld.getBreite(), spielFeld.getHeight())); // 0, 0 will automatically calculate rows and columns

        // Create and initialize the GUI elements
        initializeGUI();

        // Add KeyListener to the window
        window.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_SPACE) {
                    controller.zug();
                    window.repaint();
                }
                if (key == KeyEvent.VK_LEFT) {
                    controller.randomInit();
                }
            }
        });

        window.setVisible(true);
    }

    private void initializeGUI() {
        // Add your GUI components here, e.g., buttons, labels, etc.
        // Example:
        // JButton button = new JButton("Click Me");
        // window.add(button);
    }
}

